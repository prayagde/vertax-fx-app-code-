module.exports = {
  project: {
    ios: {
      automaticPodsInstallation: true
    }
  }
}