import {MMKV} from 'react-native-mmkv';

export default Storage = new MMKV();
