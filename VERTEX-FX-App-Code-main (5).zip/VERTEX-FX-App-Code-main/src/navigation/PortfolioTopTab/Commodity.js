import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import {color} from '../../common/color';

const Commodity = () => {
  return (
    <View style={{backgroundColor:color.color_white, flex: 1}}>
      <Text>2</Text>
    </View>
  )
}

export default Commodity

const styles = StyleSheet.create({})