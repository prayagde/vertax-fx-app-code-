export default
    DATA = [
        {
            id: 0,
            name: "• Debt Schemes",
        },
        {
            id: 1,
            name: "• Equity Schemes",
        },
        {
            id: 2,
            name: "• Habrid Schemes",
        },
        {
            id: 3,
            name: "• Other Schemes",
        },
        {
            id: 4,
            name: "• Solution Oriented Schemes",
        },
    ];
