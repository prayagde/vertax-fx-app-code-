export default
    DATA = [
        {
            id: 0,
            name: "• SIP",
        },
        {
            id: 1,
            name: "• ONE-TIME",
        },
    ];
