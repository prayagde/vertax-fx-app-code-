export default
    DATA = [
        {
            id: 0,
            name: "⭐ ⭐ ⭐ ⭐ ⭐",
        },
        {
            id: 1,
            name: "⭐ ⭐ ⭐ ⭐ & Up",
        },
        {
            id: 2,
            name: "⭐ ⭐ ⭐ & Up",
        },
        {
            id: 3,
            name: "⭐ ⭐ & Up",
        },
    ];
